﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.OpenApkFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.ButtonOpen = New System.Windows.Forms.Button()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.RemoveItemsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ButtonCheckADB = New System.Windows.Forms.Button()
        Me.ButtonInstall = New System.Windows.Forms.Button()
        Me.txtConsoleResult = New System.Windows.Forms.TextBox()
        Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.HideToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ProgressBarApkInstaller = New System.Windows.Forms.ProgressBar()
        Me.LabelProgress = New System.Windows.Forms.Label()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.ContextMenuStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'OpenApkFileDialog
        '
        Me.OpenApkFileDialog.Filter = "All files|*.*|Apk files|*.apk"
        Me.OpenApkFileDialog.Multiselect = True
        '
        'ButtonOpen
        '
        Me.ButtonOpen.Location = New System.Drawing.Point(12, 11)
        Me.ButtonOpen.Name = "ButtonOpen"
        Me.ButtonOpen.Size = New System.Drawing.Size(77, 32)
        Me.ButtonOpen.TabIndex = 0
        Me.ButtonOpen.Text = "Open file(s)"
        Me.ToolTip1.SetToolTip(Me.ButtonOpen, "Выберите apk файлы которые нужно установить")
        Me.ButtonOpen.UseVisualStyleBackColor = True
        '
        'ListBox1
        '
        Me.ListBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListBox1.ContextMenuStrip = Me.ContextMenuStrip1
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(12, 53)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ListBox1.Size = New System.Drawing.Size(292, 264)
        Me.ListBox1.TabIndex = 3
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RemoveItemsToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(204, 26)
        '
        'RemoveItemsToolStripMenuItem
        '
        Me.RemoveItemsToolStripMenuItem.Name = "RemoveItemsToolStripMenuItem"
        Me.RemoveItemsToolStripMenuItem.Size = New System.Drawing.Size(203, 22)
        Me.RemoveItemsToolStripMenuItem.Text = "Remove selected item(s)"
        '
        'ButtonCheckADB
        '
        Me.ButtonCheckADB.Location = New System.Drawing.Point(96, 11)
        Me.ButtonCheckADB.Name = "ButtonCheckADB"
        Me.ButtonCheckADB.Size = New System.Drawing.Size(77, 32)
        Me.ButtonCheckADB.TabIndex = 1
        Me.ButtonCheckADB.Text = "Check ADB"
        Me.ToolTip1.SetToolTip(Me.ButtonCheckADB, "Проверить подключен ли телефон к ПК в режиме отладки по ADB")
        Me.ButtonCheckADB.UseVisualStyleBackColor = True
        '
        'ButtonInstall
        '
        Me.ButtonInstall.Location = New System.Drawing.Point(180, 11)
        Me.ButtonInstall.Name = "ButtonInstall"
        Me.ButtonInstall.Size = New System.Drawing.Size(77, 32)
        Me.ButtonInstall.TabIndex = 2
        Me.ButtonInstall.Text = "Install apk(s)"
        Me.ToolTip1.SetToolTip(Me.ButtonInstall, "Установить apk файлы на телефон")
        Me.ButtonInstall.UseVisualStyleBackColor = True
        '
        'txtConsoleResult
        '
        Me.txtConsoleResult.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtConsoleResult.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtConsoleResult.ContextMenuStrip = Me.ContextMenuStrip2
        Me.txtConsoleResult.Font = New System.Drawing.Font("Courier New", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.txtConsoleResult.ForeColor = System.Drawing.SystemColors.MenuText
        Me.txtConsoleResult.HideSelection = False
        Me.txtConsoleResult.Location = New System.Drawing.Point(101, 53)
        Me.txtConsoleResult.Multiline = True
        Me.txtConsoleResult.Name = "txtConsoleResult"
        Me.txtConsoleResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtConsoleResult.Size = New System.Drawing.Size(203, 264)
        Me.txtConsoleResult.TabIndex = 4
        Me.txtConsoleResult.Visible = False
        '
        'ContextMenuStrip2
        '
        Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HideToolStripMenuItem})
        Me.ContextMenuStrip2.Name = "ContextMenuStrip2"
        Me.ContextMenuStrip2.Size = New System.Drawing.Size(100, 26)
        '
        'HideToolStripMenuItem
        '
        Me.HideToolStripMenuItem.Name = "HideToolStripMenuItem"
        Me.HideToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.HideToolStripMenuItem.Text = "Hide"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(264, 11)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(40, 32)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Help"
        Me.ToolTip1.SetToolTip(Me.Button1, "Краткая справка")
        Me.Button1.UseVisualStyleBackColor = True
        '
        'ProgressBarApkInstaller
        '
        Me.ProgressBarApkInstaller.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ProgressBarApkInstaller.Location = New System.Drawing.Point(12, 321)
        Me.ProgressBarApkInstaller.Name = "ProgressBarApkInstaller"
        Me.ProgressBarApkInstaller.Size = New System.Drawing.Size(200, 15)
        Me.ProgressBarApkInstaller.Step = 5
        Me.ProgressBarApkInstaller.TabIndex = 6
        Me.ProgressBarApkInstaller.Visible = False
        '
        'LabelProgress
        '
        Me.LabelProgress.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.LabelProgress.Location = New System.Drawing.Point(218, 321)
        Me.LabelProgress.Name = "LabelProgress"
        Me.LabelProgress.Size = New System.Drawing.Size(39, 15)
        Me.LabelProgress.TabIndex = 7
        Me.LabelProgress.Text = "%"
        Me.LabelProgress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.LabelProgress.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(316, 341)
        Me.Controls.Add(Me.LabelProgress)
        Me.Controls.Add(Me.ProgressBarApkInstaller)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtConsoleResult)
        Me.Controls.Add(Me.ButtonInstall)
        Me.Controls.Add(Me.ButtonCheckADB)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.ButtonOpen)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Apk installer"
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ContextMenuStrip2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OpenApkFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ButtonOpen As System.Windows.Forms.Button
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents RemoveItemsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ButtonCheckADB As System.Windows.Forms.Button
    Friend WithEvents ButtonInstall As System.Windows.Forms.Button
    Friend WithEvents txtConsoleResult As System.Windows.Forms.TextBox
    Friend WithEvents ContextMenuStrip2 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents HideToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents ProgressBarApkInstaller As System.Windows.Forms.ProgressBar
    Friend WithEvents LabelProgress As System.Windows.Forms.Label

End Class
